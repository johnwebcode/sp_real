<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Floors extends Model
{
    
	protected $table = 'floor';
	
	protected $fillable = ['name', 'short_name', 'number', 'status'];
}
