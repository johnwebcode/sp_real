<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParkingDetails extends Model
{
    protected $table = 'parking_details';
    protected $fillable = ['name', 'car_number', 'mobile', 'cost','status','floor_id','slot_no','image','created_by','in_time','out_time','parking_type'];
}
