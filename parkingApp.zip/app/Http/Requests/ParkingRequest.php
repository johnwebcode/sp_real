<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class ParkingRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
		
        return [
            'car_number' => array('required','alpha_num'),
            'name' => array('required','min:3','max:20','alpha'),
            'mobile' => array('required','digits_between:8,10','numeric'),
            'type' => array('required'),
//            'image' => array('required','image','mimes:jpeg,jpg,bmp,png'),
            'image' => array('required'),
            'parking_type' => array('required'),
            ];
    }
}
