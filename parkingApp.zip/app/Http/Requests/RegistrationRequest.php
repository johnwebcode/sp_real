<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class RegistrationRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => array('required','unique:users,email','email'),
            'first_name' => array('required','min:2','max:20','alpha'),
            'last_name' => array('required','min:2','max:20','alpha'),
            'gender' => array('required'),
            'password' => array('required','min:4','max:20'),
            'staff_id' => array('required'),
            'floor' => array('required')
			
              ];
    }
}
